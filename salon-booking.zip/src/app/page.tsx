import Link from 'next/link';
import { Calendar, Users, Clock, Sparkles, Download, Star, CheckCircle2 } from 'lucide-react';
import HomeClient from './HomeClient';

export default function Home() {
  return <HomeClient />;
}
